<EN> Installation 

1. Extract the archive on desktop.
2. Open "Open IV", enable edit mode, go to <<mods/update/update.rpf/x64/data/lang>> and replace american_rel.rpf.
Also, you have a backup file in case you don t like the mode. This mod replaces english language to romanian language.

<RO> Instalare

1. Extrageti arhiva pe desktop.
2. Deschide "Open IV", activeaza edit mode, si du-te la <<mods/update/update.rpf/x64/data/lang>> si inlocuieste american_rel.rpf.
De asemenea, ave?i un fi?ier de rezerva �n caz ca nu va place modul. Acest mod �nlocuie?te limba engleza cu limba rom�na.