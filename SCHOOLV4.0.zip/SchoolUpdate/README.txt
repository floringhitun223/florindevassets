🏫 SCHOOL V – FINAL VERSION (UPDATED)
By Daron Hunter

--------------------------------------------
OVERVIEW
--------------------------------------------
This is an UPDATED release of the FINAL version of the SCHOOL V map.  
It includes new rooms, areas, and visual upgrades that complete the project.  
No further updates will be released.

SCHOOL V is a detailed and realistic school environment for GTA V, built with care and optimized for better performance.

--------------------------------------------
CHANGE LOG
--------------------------------------------
GENERAL IMPROVEMENTS:
- Retextured most of the rooms for a cleaner, more realistic look.
- Added several new rooms and extended hallways.
- Added new offices.
- Added a new outdoor recreation space.
- Redesigned and improved the cafeteria structure.
- Updated all classrooms with better layouts and props.
- Improved lighting, placement, and overall map quality.
- Fixed minor alignment and collision issues.

NEW ADDITIONS:
- Second Floor added:
   • Sport Room
   • Janitor Room
- Added a bigger main classroom.
- Added a small new classroom.
- Relocated the bathroom.
- Many visual tweaks and prop adjustments.

--------------------------------------------
NEW IN THIS UPDATED VERSION
--------------------------------------------
- Added "part3.ymap" and "part4.ymap" for complete structure support.
- Further optimized props and textures.
- Performance improvements for smoother loading.
- Final polish on exterior areas.

--------------------------------------------
REQUIREMENTS
--------------------------------------------
Make sure you have these mods/tools installed:
- MENYOO
- SCRIPTHOOKV
- MAP BUILDER
- MENYOO TO YMAP CONVERTER

(These are the main required mods; missing any of them may cause loading errors.)

--------------------------------------------
INSTALLATION GUIDE
--------------------------------------------
STEP 1 - INSTALL YMAP FILES
Copy all four YMAP files into your custom maps folder:

   part1.ymap  
   part2.ymap  
   part3.ymap  
   part4.ymap

Path:
mods/update/x64/dlcpacks/custom_maps/dlc.rpf/x64/levels/gta5/_citye/maps/custom_maps


STEP 2 - INSTALL MENYOO XML FILE
Copy "SchoolUpdate.xml" into:
Grand Theft Auto V/MenyooStuff/Spooner


STEP 3 - LOAD THE MAP IN GAME
1. Start GTA V.
2. Open Menyoo.
3. Go to Object Spooner → Manage Saved Files.
4. Select "SchoolUpdate.xml" and click "Load Placements".


--------------------------------------------
NOTES
--------------------------------------------
- The map contains more than 2045 props, exceeding Menyoo’s limit.
  That’s why it’s provided in YMAP format for full loading.

- The "SchoolUpdate.xml" file is only used to teleport to the school’s location.

Coordinates:
X: -1668.81616  
Y: 233.831223  
Z: 1480.60925

- The map does NOT include NPCs or peds.  
  It’s an empty environment so you can build your own scenarios.

- Because of the large number of props, a decent PC is recommended.  
  Keep an eye on performance and temperature while loading.

--------------------------------------------
CREDITS
--------------------------------------------
Created and Updated by: Daron Hunter  
Special thanks to the GTA V modding community for the tools and inspiration.

--------------------------------------------
THANK YOU
--------------------------------------------
Thank you for downloading and supporting the SCHOOL V project!  
Enjoy exploring, building, and creating your own stories in this final and complete version of the map.
